const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');
const uuidv4 = require('uuid/v4');
const moment = require('moment');

const auth = require('../middleware/auth');
const db = require('../config/database');
const adminOnly = require('../middleware/adminOnly');

const timestamp = moment(Date.now()).format('YYYY-MM-DD HH:mm:ss');
const secretKey = config.get('jwtSecretKey');

// @route   GET api/information
// @desc    Get all informations
// @access  Private
router.get('/', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM information ORDER BY created_on DESC';
		const data = await db.query(sql);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get informations',
			data: req.body,
			errors: err,
		});
	}
});

// @route   GET api/information/latest
// @desc    Get 5 latest informations
// @access  Private
router.get('/latest', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM information ORDER BY created_on DESC LIMIT 5';
		const data = await db.query(sql);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get informations',
			data: req.body,
			errors: err,
		});
	}
});

// @route   GET api/information/limit/:limit
// @desc    Get 5 latest informations
// @access  Private
router.get('/limit/:limit', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM information ORDER BY created_on DESC LIMIT ?';
		const data = await db.query(sql, req.params.limit);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get informations',
			data: req.body,
			errors: err,
		});
	}
});


// @route   GET api/information/:limit/:offset
// @desc    Get pagination announcement
// @access  Private
router.get('/', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM information ORDER BY created_on DESC LIMIT ?,?';
		const data = await db.query(sql, [req.params.offset, req.params.limit]);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get informations',
			data: req.body,
			errors: err,
		});
	}
});

// @route   POST api/information
// @desc    Create new information
// @access  Private, AdminOnly
router.post(
	'/',
	[
		auth,
		adminOnly,
		[
			check('title', 'Please enter title')
				.not()
				.isEmpty(),
		],
	],
	async (req, res) => {
		const errors = validationResult(req);

		if (!errors.isEmpty()) {
			return res.status(400).json({
				status: 400,
				message: 'Bad request',
				data: req.body,
				errors: errors.array(),
			});
		}

		try {
			const token = req.header('x-auth-token');
			const decoded = jwt.verify(token, secretKey);
			const createdBy = decoded.user.id;
			const uid = uuidv4();
			const { title, text } = req.body;

			const sql = 'INSERT INTO information (id, title, text, created_on, created_by) ' + 'VALUES (?, ?, ?, ?, ?)';

			await db.query(sql, [uid, title, text, timestamp, createdBy]);

			res.status(200).json({
				status: 200,
				message: 'OK',
				data: req.body,
				errors: null,
			});
		} catch (err) {
			console.error(err.message);
			res.status(500).json({
				status: 500,
				message: 'Create new information failed',
				data: req.body,
				errors: err,
			});
		}
	}
);

// @route   POST api/information/update
// @desc    Update existing information
// @access  Private, AdminOnly
router.post(
	'/update',
	[
		auth,
		adminOnly,
		[
			check('title', 'Please enter title')
				.not()
				.isEmpty(),
			check('id', 'Please provide information id')
				.not()
				.isEmpty(),
		],
	],
	async (req, res) => {
		const errors = validationResult(req);

		if (!errors.isEmpty()) {
			return res.status(400).json({
				status: 400,
				message: 'Bad request',
				data: req.body,
				errors: errors.array(),
			});
		}

		try {
			const token = req.header('x-auth-token');
			const decoded = jwt.verify(token, secretKey);
			const createdBy = decoded.user.id;
			const { title, text, id } = req.body;

			const sql = 'UPDATE information SET title=?, text=?, updated_on=?, updated_by=? WHERE id=?';

			await db.query(sql, [title, text, timestamp, createdBy, id]);

			res.status(200).json({
				status: 200,
				message: 'OK',
				data: req.body,
				errors: null,
			});
		} catch (err) {
			console.error(err.message);
			res.status(500).json({
				status: 500,
				message: 'Update information failed',
				data: req.body,
				errors: err,
			});
		}
	}
);

// @route   POST api/information/delete
// @desc    Delete a information
// @access  private, admin only
router.post(
	'/delete',
	[
		auth,
		adminOnly,
		[
			check('id')
				.not()
				.isEmpty(),
		],
	],
	async (req, res) => {
		const errors = validationResult(req);

		if (!errors.isEmpty()) {
			return res.status(400).json({
				status: 400,
				message: 'Error',
				data: req.body,
				errors: errors.array(),
			});
		}

		const { id } = req.body;

		try {
			const sql = 'DELETE FROM information WHERE id = ?';
			await db.query(sql, id);

			return res.status(200).json({
				status: 200,
				message: 'Delete information success.',
				data: req.body,
				errors: null,
			});
		} catch (err) {
			console.log('Failed to delete information, error : ', err.message);
			return res.status(500).json({
				status: 500,
				message: 'Failed to delete information',
				data: req.body,
				errors: err,
			});
		}
	}
);

module.exports = router;
