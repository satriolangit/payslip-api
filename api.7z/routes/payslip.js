const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');
const uuidv4 = require('uuid/v4');
const moment = require('moment');
const IncomingForm = require('formidable').IncomingForm;
const fs = require('fs');

//local lib
const auth = require('../middleware/auth');
const db = require('../config/database');
const adminOnly = require('../middleware/adminOnly');

//utils
const timestamp = moment(Date.now()).format('YYYY-MM-DD HH:mm:ss');
const secretKey = config.get('jwtSecretKey');

router.post('/upload', (req, res) => {
	var form = new IncomingForm();

	form.on('fileBegin', function(name, file) {
		file.path = __dirname + '/../public/payslip/' + file.name;
	});

	form.on('file', (field, file) => {
		// Do something with the file
		// e.g. save it to the database
		// you can access it using file.path

		var pdf = file.name;
		var filenames = pdf.split('_');
		const year = filenames[0].substring(0, 4);
		const month = filenames[0].substring(4);
		const employeeId = filenames[1];
		const lastName = filenames[3].split('.')[0];
		const employeeName = filenames[2] + ' ' + lastName;

		//save to db

		try {
			// const token = req.header('x-auth-token');
			// const decoded = jwt.verify(token, secretKey);
			// const createdBy = decoded.user.id;

			const sql =
				'INSERT INTO payslip (employee_id, employee_name, year, month, filename, created_on, created_by) ' +
				'VALUES (?, ?, ?, ?, ?, ?, ?)';

			db.query(sql, [employeeId, employeeName, year, month, pdf, timestamp, 0]);
		} catch (error) {
			console.log(error);
		}
	});
	form.on('end', () => {
		res.json();
	});
	form.parse(req);
});

router.get('/download/:filename', (req, res) => {
	try {
		const filename = req.params.filename;
		const path = './public/payslip/' + filename;
		var file = fs.createReadStream(path);
		file.pipe(res);
	} catch (error) {
		console.log(error);
	}
});

// @route   GET api/payslip
// @desc    Get all payslip
// @access  Private
router.get('/', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM payslip ORDER BY year, month DESC';
		const data = await db.query(sql);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get payslip',
			data: req.body,
			errors: err,
		});
	}
});

// @route   GET api/payslip/:employeeId
// @desc    Get employee payslip
// @access  Private
router.get('/:employeeId', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM payslip WHERE employee_id = ? ORDER BY year, month DESC';
		const data = await db.query(sql, req.params.employeeId);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get payslip',
			data: req.body,
			errors: err,
		});
	}
});

// @route   GET api/payslip/:employeeId/:limit
// @desc    Get employee payslip top limit
// @access  Private
router.get('/:employeeId/:limit', auth, async (req, res) => {
	try {
		const sql = 'SELECT * FROM payslip WHERE employee_id = ? ORDER BY year, month DESC LIMIT ?';
		const data = await db.query(sql, [req.params.employeeId, req.params.limit]);

		res.status(200).json({
			status: 200,
			message: 'OK',
			data: data,
			errors: null,
		});
	} catch (err) {
		console.error(err.message);
		res.status(500).json({
			status: 500,
			message: 'Failed to get payslip',
			data: req.body,
			errors: err,
		});
	}
});

module.exports = router;
